/*

     ██╗███████╗██████╗ ██╗ ██████╗██████╗ ███╗   ███╗
     ██║██╔════╝██╔══██╗██║██╔════╝██╔══██╗████╗ ████║
     ██║█████╗  ██║  ██║██║██║     ██████╔╝██╔████╔██║
██   ██║██╔══╝  ██║  ██║██║██║     ██╔══██╗██║╚██╔╝██║
╚█████╔╝███████╗██████╔╝██║╚██████╗██║  ██║██║ ╚═╝ ██║
╚════╝ ╚══════╝╚═════╝ ╚═╝ ╚═════╝╚═╝  ╚═╝╚═╝     ╚═╝
                                                      
Consultant Willi Santana
JediCRM Online
*/
import com.sap.gateway.ip.core.customdev.util.Message;
import java.util.HashMap;
import groovy.xml.*;

def Message processData(Message message) {

    def header = message.getHeaders() as String;
    def body = message.getBody(java.lang.String) as String;
    def messageLog = messageLogFactory.getMessageLog(message);
    
    def properties = message.getProperties() as String;
    
    def bodyPretty = XmlUtil.serialize(body);
    
    if (messageLog != null){
        messageLog.setStringProperty("Log4", "Print Payload");
        messageLog.addAttachmentAsString("4 - Payload de Resposta", bodyPretty, "text/plain");
        
    }

       return message;
}