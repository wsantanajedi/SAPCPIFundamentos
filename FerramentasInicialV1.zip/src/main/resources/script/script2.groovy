/*

     ██╗███████╗██████╗ ██╗ ██████╗██████╗ ███╗   ███╗
     ██║██╔════╝██╔══██╗██║██╔════╝██╔══██╗████╗ ████║
     ██║█████╗  ██║  ██║██║██║     ██████╔╝██╔████╔██║
██   ██║██╔══╝  ██║  ██║██║██║     ██╔══██╗██║╚██╔╝██║
╚█████╔╝███████╗██████╔╝██║╚██████╗██║  ██║██║ ╚═╝ ██║
╚════╝ ╚══════╝╚═════╝ ╚═╝ ╚═════╝╚═╝  ╚═╝╚═╝     ╚═╝
                                                      
Consultant Willi Santana
JediCRMn Online
*/
import com.sap.gateway.ip.core.customdev.util.Message;
import java.util.HashMap;
import groovy.json.*;
def Message processData(Message message) {
    //Body 
       def body = message.getBody(java.lang.String) as String;
       def messageLog = messageLogfactory.getMessageLog(message);
       
       if (messageLog != null) {
           messageLog.setStringPropert("Logging", "Grava Payload de Entrada");
           messageLog.addAttachmentAsString("Payload de Entrada JSON", body,  "text/plain");
       }
       

       return message;
}