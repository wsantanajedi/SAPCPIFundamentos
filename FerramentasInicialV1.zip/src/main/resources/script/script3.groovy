/*

     ██╗███████╗██████╗ ██╗ ██████╗██████╗ ███╗   ███╗
     ██║██╔════╝██╔══██╗██║██╔════╝██╔══██╗████╗ ████║
     ██║█████╗  ██║  ██║██║██║     ██████╔╝██╔████╔██║
██   ██║██╔══╝  ██║  ██║██║██║     ██╔══██╗██║╚██╔╝██║
╚█████╔╝███████╗██████╔╝██║╚██████╗██║  ██║██║ ╚═╝ ██║
╚════╝ ╚══════╝╚═════╝ ╚═╝ ╚═════╝╚═╝  ╚═╝╚═╝     ╚═╝
                                                      
Consultant Willi Santana
JediCRM Online
*/
import com.sap.gateway.ip.core.customdev.util.Message;
import java.util.HashMap;
import groovy.json.*;
def Message processData(Message message) {
    //Body 
       def body = message.getBody(java.lang.String) as String
       def messageLog = messageLogFactory.getMessageLog(message);
       if (messageLog != null) {
           messageLog.setStringProperty("Log1", "Print payload");
           messageLog.addAttachmentAsString("1 - Grava payload de entrada", body, "text/plain");
       }

       return message;
}